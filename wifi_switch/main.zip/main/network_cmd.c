#include "cJSON.h"
#include <stdio.h>
#include "network_cmd.h"
#include "switch_task.h"
#include "network_task.h"

const char *channel_keys[] = {"ch1_status", "ch2_status", "ch3_status"};


char* cmd_macToTopic(void) {
    if (g_netMac == NULL || g_topic == NULL) {
        ESP_LOGE(MQTT_TAG, "Lỗi: Con trỏ MAC hoặc Topic NULL.");
        return NULL;
    }
    strcpy(g_topic, ROOT_TOPIC);
    sprintf(g_topic + ROOT_TOPIC_LEN,
            "%02X%02X%02X%02X%02X%02X",
            g_netMac[0], g_netMac[1], g_netMac[2],
            g_netMac[3], g_netMac[4], g_netMac[5]);
    return g_topic;
}

void cmd_parse_ctrlData(int data_len, const char *data) {
    if (!data || data_len <= 0) {
        ESP_LOGE(MQTT_TAG, "Data is not valid");
        return;
    }
    char *json_string = strndup(data, data_len);
    if (!json_string) {
        ESP_LOGE(MQTT_TAG, "Error malloc");
        return;
    }
    cJSON *root = cJSON_Parse(json_string);
    free(json_string);

    if (root == NULL) {
        ESP_LOGE(MQTT_TAG, "Json parse error");
        if (cJSON_GetErrorPtr() != NULL) {
            ESP_LOGE(MQTT_TAG, "Json error: %s", cJSON_GetErrorPtr());
        }
        return;
    }
    ESP_LOGI(MQTT_TAG, "Data : %s", data);
    for (int i = 0; i < 3; i++) {
        cJSON *channel_item = cJSON_GetObjectItemCaseSensitive(root, channel_keys[i]);
        if (cJSON_IsNumber(channel_item)) {
            int state = channel_item->valueint;
            if (state == 0 || state == 1) {
                set_output_state(i, state);
            } else {
                ESP_LOGW(MQTT_TAG, "%s có giá trị không hợp lệ: %d", channel_keys[i], state);
            }
        }
    }
    cJSON_Delete(root);
}

void cmd_pub_staData(int i, int status) {
    const char *key_name = NULL;
    switch (i) {
        case 0:
            key_name = "ch1_status";
            break;
        case 1:
            key_name = "ch2_status";
            break;
        case 2:
            key_name = "ch3_status";
            break;
        default:
            ESP_LOGE(MQTT_TAG, "Invalid channel index: %d", i);
            return;
    }

    if (mqtt_client == NULL) {
        ESP_LOGW(MQTT_TAG, "MQTT Client not ready");
        return;
    }

    cJSON *root = cJSON_CreateObject();
    if (root == NULL) {
        ESP_LOGE(MQTT_TAG, "Failed to create JSON root");
        return;
    }

    cJSON_AddNumberToObject(root, key_name, status);
    char *payload = cJSON_PrintUnformatted(root);
    if (payload == NULL) {
        cJSON_Delete(root);
        ESP_LOGE(MQTT_TAG, "Failed to print JSON");
        return;
    }
    int msg_id = esp_mqtt_client_publish(mqtt_client, g_topic, payload, 0, 1, 0);
    if (msg_id != -1) {
        ESP_LOGI(MQTT_TAG, "Published to %s: %s", g_topic, payload);
    } else {
        ESP_LOGE(MQTT_TAG, "Publish failed");
    }

    cJSON_free(payload);
    cJSON_Delete(root);
}

char* create_device_status_json(int relay_id, int status){
    cJSON *root = cJSON_CreateObject();
    cJSON_AddNumberToObject(root, "id", relay_id);
    cJSON_AddStringToObject(root, "status", (status == 1) ? "ON" : "OFF");
    char *json_string = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);
    return json_string;
}

void publish_data_example(void) {
    char *payload = create_device_status_json(1, 1);
    if (payload != NULL) {
        printf("JSON Payload to publish: %s\n", payload);
        cJSON_free(payload);
    }
}