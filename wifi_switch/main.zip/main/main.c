#include "switch_task.h"
#include "network_task.h"

void app_main(void)
{
    gpio_init();
    ESP_ERROR_CHECK(nvs_flash_init());
    ESP_ERROR_CHECK(esp_netif_init());
    wifi_init_sta();

    xTaskCreate(gpio_polling_task, "gpio_polling_task", 4096, NULL, 5, NULL);
    ESP_LOGI(SWITCH_TAG, "System initialized. LED control active via Polling.");
    ESP_LOGI(WIFI_TAG, "ESP wifi init success");
}
